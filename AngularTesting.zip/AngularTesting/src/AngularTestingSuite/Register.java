package AngularTestingSuite;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class Register {
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\hp\\Downloads\\chromedriver_win32 (2)\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
 
        String url = "http://localhost:4200/signup";
 
        driver.get(url);
        driver.manage().window().maximize();
        driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
 
 
        WebElement login = driver.findElement(By.linkText("Register"));
        System.out.println("Clicking on the login element in the main page");
        login.click();
 
        driver.manage().timeouts().pageLoadTimeout(10,TimeUnit.SECONDS);
 
        WebElement email = driver.findElement(By.id("email"));
        WebElement password = driver.findElement(By.id("password"));
        WebElement first = driver.findElement(By.id("first"));
        WebElement last = driver.findElement(By.id("last"));
        WebElement locations = driver.findElement(By.id("locations"));
        WebElement mobile = driver.findElement(By.id("mobile"));
        WebElement RegisterButton = driver.findElement(By.id("register-button"));
 
        email.clear();
        System.out.println("Entering the email");
        email.sendKeys("vishalyadav22334455@gmail.com");
 
        password.clear();
        System.out.println("entering the password");
        password.sendKeys("98191");
        
        first.clear();
        System.out.println("entering the first name");
        first.sendKeys("Vi");
        
        last.clear();
        System.out.println("entering the last name");
        last.sendKeys("ya");
        
        locations.clear();
        System.out.println("entering the locations");
        locations.sendKeys("mu");
        
        mobile.clear();
        System.out.println("entering the mobile");
        mobile.sendKeys("9819888776");
 
        System.out.println("Clicking register button");
        RegisterButton.click();
 
        String title = "IssueTracker";
 
        String actualTitle = driver.getTitle();
 
        System.out.println("Verifying the page title has started");
        Assert.assertEquals(actualTitle,title,"Page title doesnt match");
 
        System.out.println("The page title has been successfully verified");
 
        System.out.println("User Register in successfully");
 
        //driver.quit();
		
	}

}
